#ifndef INTERNET_H // Se ainda não tiver incluído este arquivo
#define INTERNET_H // Marca que este arquivo foi incluído

void conectaWifi();
void checkWifi();


#endif // Fim da proteção contra incluir este arquivo mais de uma vez